﻿using DILib;

namespace DIconsoleUI
{
    public interface IDAL { }
    public class DAL : IDAL { }
    public class Program
    {
        static void Main(string[] args)
        {
            DIContainer dic = new DIContainer();
            dic.Register< IDAL, DAL>();
        }
    }
}
